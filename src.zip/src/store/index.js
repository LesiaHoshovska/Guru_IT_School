import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    toursList: [
      {
        id: 1,
        tourTittle: 'Kazbek',
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
      },
      {
        id: 2,
        tourTittle: 'Kamchatka',
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
      },
      {
        id: 3,
        tourTittle: 'Elbrus',
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
      },
    ],
  },
  mutations: {},
  actions: {},
  getters: {
    getToursList: ({ toursList }) => toursList,
  },
  modules: {},
});

export default store;
