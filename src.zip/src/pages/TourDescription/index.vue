<template>
  <div>
    Tour Description
  </div>
</template>

<script>
export default {
  name: 'TourDescription',
};
</script>

<style></style>
