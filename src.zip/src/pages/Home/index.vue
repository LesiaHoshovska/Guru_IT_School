<template>
  <div>
    <div>Home</div>
    <div>Filter</div>
    <div>
      <h1>Our Programs</h1>
      <div class="content">
        <TourCard
          v-for="tour in getToursList"
          :key="tour.id"
          :tourTittle="tour.tourTittle"
          :toursDaysAmount="tour.toursDaysAmount"
          :toursTotalDistance="tour.toursTotalDistance"
          :toursPrice="tour.toursPrice"
        />
      </div>
    </div>
  </div>
</template>

<script>
import TourCard from '../../components/TourCard/index.vue';
import { mapGetters } from 'vuex';

export default {
  name: 'Home',
  components: {
    TourCard,
  },
  computed: {
    ...mapGetters(['getToursList']),
  },
};
</script>

<style>
.content {
  display: flex;
  width: 150px;
  height: 125px;
}
</style>
