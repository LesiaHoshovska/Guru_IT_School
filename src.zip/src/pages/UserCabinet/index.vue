<template>
  <div>
      User Cabinet
  </div>
</template>

<script>
export default {
name: 'UserCabinet'
}
</script>

<style>

</style>