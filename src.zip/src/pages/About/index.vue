<template>
  <div>
    About us
  </div>
</template>

<script>
export default {
  name: 'About',
};
</script>

<style></style>
