<template>
  <div>
    <div>Home</div>
    <div>Filter</div>
    <div>
      <h1>Our Programs</h1>
      <div class="filter">
        <div>
          <label>
            Location
            <input type="text" v-model="searchLocation" />
          </label>
        </div>
        <div>
          <label>
            Date
            <input type="number" v-model="searchDate" />
          </label>
        </div>
      </div>
      <div class="content">
        <TourCard
          v-for="tour in getToursList"
          :key="tour.id"
          :tourTittle="tour.tourTittle"
          :toursDaysAmount="tour.toursDaysAmount"
          :toursTotalDistance="tour.toursTotalDistance"
          :toursPrice="tour.toursPrice"
        />
      </div>
    </div>
  </div>
</template>

<script>
import TourCard from "../../components/TourCard/index.vue";
import { mapGetters } from "vuex";

export default {
  name: "Home",
  components: {
    TourCard,
  },
  data() {
    return {
      searchLocation: null,
      searchDate: null,
    };
  },
  watch: {
    searchLocation() {
      this.getLocation();
    },
  },
  computed: {
    ...mapGetters(["getToursList"]),
  },
  methods: {
    ...mapGetters(["getFilteredTours"]),
    getLocation() {
      this.getFilteredTours(this.searchLocation.toLowerCase());
    },
  },
  mounted() {
    if (this.tourId) {
      const tour = this.getTourById(this.tourId);
      this.tourTittle = tour.tourTittle;
      (this.toursDaysAmount = tour.toursDaysAmount),
        (this.toursTotalDistance = tour.toursTotalDistance),
        (this.toursPrice = tour.toursPrice);
    }
  },
};
</script>

<style>
.content {
  display: flex;
  flex-wrap: wrap;
}
.filter {
  display: flex;
  justify-content: center;
}
</style>
