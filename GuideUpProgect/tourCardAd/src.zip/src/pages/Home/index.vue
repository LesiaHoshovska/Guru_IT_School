<template>
  <div>
    <div>Home</div>
    <div>Filter</div>
    <div>
      <h1>Our Programs</h1>
      <div class="filter">
        <div>
          <label>
            Location
            <input type="text" v-model="searchLocation" />
          </label>
        </div>
        <div>
          <label>
            Date
            <input type="number" v-model="searchDate" />
          </label>
        </div>
      </div>
      <div class="content">
        <TourCard
          v-for="tour in filteredTours"
          :key="tour.id"
          :tourTittle="tour.tourTittle"
          :toursDaysAmount="tour.toursDaysAmount"
          :toursTotalDistance="tour.toursTotalDistance"
          :toursPrice="tour.toursPrice"
        />
      </div>
    </div>
  </div>
</template>

<script>
import TourCard from "../../components/TourCard/index.vue";
import { mapGetters } from "vuex";

export default {
  name: "Home",
  components: {
    TourCard,
  },
  data() {
    return {
      searchLocation: null,
      searchDate: null,
      filteredTours: mapGetters(["getToursList"]),
      updateKey: 0,
    };
  },
  watch: {
    searchLocation() {
      this.filterLocation();
    },
  },
  computed: {
    ...mapGetters(["getToursList"]),
  },
  methods: {
    ...mapGetters(["getFilteredTours"]),
    filterLocation() {
      const val = this.searchLocation.toLowerCase();
      this.filteredTours = this.getToursList.filter(
        (tour) => !val || tour.tourTittle.toLowerCase().startsWith(val),
        this.updateKey++
      );
    },
  },
  mounted() {
    this.filteredTours = this.searchLocation();
  },
};
</script>

<style>
.content {
  display: flex;
  flex-wrap: wrap;
}
.filter {
  display: flex;
  justify-content: center;
}
</style>
