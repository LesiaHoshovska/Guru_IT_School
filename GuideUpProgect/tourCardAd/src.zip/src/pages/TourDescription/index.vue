<template>
  <div>
    Tour Description
    <div>
      <TourDayDescription
        v-for="day in getDaysList"
        :key="day.id"
        :dayNumber="day.dayNumber"
        :dayTittle="day.dayTittle"
        :dayDescription="day.dayDescription"
        :dayPicsSrc="day.dayPicsSrc"
      />
    </div>
  </div>
</template>

<script>
import TourDayDescription from "../../components/TourDayDescription/index.vue";
import { mapGetters } from "vuex";
export default {
  name: "TourDescription",
  components: {
    TourDayDescription,
    computed: {
      ...mapGetters(["getDaysList"]),
    },
  },
};
</script>

<style></style>
