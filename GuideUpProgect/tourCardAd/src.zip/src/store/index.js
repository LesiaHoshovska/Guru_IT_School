import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    toursList: [
      {
        id: 1,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
        daysList: [
          {
            id: 1,
            dayNumber: 1,
            dayTittle: "Arrival",
            dayDescription: "The first day",
            dayPicsSrc:
              "https://extremeguide.pro/wp-content/gallery/kamchatka2/thumbs/thumbs_DSC_8713.JPG",
          },
          {
            id: 2,
            dayNumber: 2,
            dayTittle: "Arrival",
            dayDescription: "The first day",
            dayPicsSrc:
              "https://extremeguide.pro/wp-content/gallery/kamchatka2/thumbs/thumbs_DSC_8713.JPG",
          },
          {
            id: 3,
            dayNumber: 3,
            dayTittle: "Arrival",
            dayDescription: "The first day",
            dayPicsSrc:
              "https://extremeguide.pro/wp-content/gallery/kamchatka2/thumbs/thumbs_DSC_8713.JPG",
          },
        ],
      },
      {
        id: 2,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 3,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 4,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 5,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 6,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 7,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 8,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 9,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 10,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 11,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 12,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
    ],
  },
  mutations: {},
  actions: {},
  getters: {
    getToursList: ({ toursList }) => toursList,
    getTourById: (state) => (id) =>
      state.toursList.find((item) => item.id === id),
    getDaysList:
      ({ toursList }) =>
      (id) =>
        toursList[id].daysList,
  },
  modules: {},
});

export default store;
