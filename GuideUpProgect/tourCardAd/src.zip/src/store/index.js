import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    toursList: [
      {
        id: 1,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 2,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 3,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 4,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 5,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 6,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 7,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 8,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 9,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
      {
        id: 10,
        tourTittle: "Kazbek",
        toursDaysAmount: 6,
        toursTotalDistance: 30,
        toursPrice: 500,
        toursDate: [],
      },
      {
        id: 11,
        tourTittle: "Kamchatka",
        toursDaysAmount: 15,
        toursTotalDistance: 80,
        toursPrice: 1500,
        toursDate: [],
      },
      {
        id: 12,
        tourTittle: "Elbrus",
        toursDaysAmount: 8,
        toursTotalDistance: 50,
        toursPrice: 700,
        toursDate: [],
      },
    ],
  },
  mutations: {},
  actions: {},
  getters: {
    getToursList: ({ toursList }) => toursList,
    getTourById: (state) => (id) =>
      state.toursList.find((item) => item.id === id),
    getFilteredTours: (state) => (tourTittle) =>
      state.toursList.filter((tour) =>
        tourTittle.toLowerCase().startsWith(tour)
      ),
  },
  modules: {},
});

export default store;
