import Vue from "vue";
import VueRouter from "vue-router";

import About from "../pages/About";
import Home from "../pages/Home/index.vue";
import TourDescription from "../pages/TourDescription/index.vue";
import UserCabinet from "../pages/UserCabinet/index.vue";

Vue.use(VueRouter);

const routes = [
  { path: "/", name: "home", component: Home },
  { path: "/about", name: "about", component: About },
  { path: "/user-cabinet", name: "user-cabinet", component: UserCabinet },
  {
    path: "/description/:tour_id?",
    name: "description",
    component: TourDescription,
  },
];

const router = new VueRouter({
  mode: "history",
  routes,
});

export default router;
