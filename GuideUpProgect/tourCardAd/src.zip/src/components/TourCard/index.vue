<template>
  <div class="card" @click="goToDescription(tour_id)">
    <div><img :src="imgSrc" alt="Everest Base camp" /></div>
    <div>
      <h1>{{ tourTittle }}</h1>
    </div>
    <div>
      <h1>{{ toursDaysAmount }}</h1>
    </div>
    <div>
      <h1>{{ toursTotalDistance }}</h1>
    </div>
    <div>
      <h1>{{ toursPrice }}</h1>
    </div>
  </div>
</template>

<script>
export default {
  name: "TourCard",
  props: {
    imgSrc: {
      type: String,
      default:
        "https://extremeguide.pro/wp-content/uploads/2018/12/BXiM0Jy2AY8.jpg",
    },
    tourTittle: {
      type: String,
      default: "Trekking to Everest base Camp",
    },
    toursDaysAmount: {
      type: Number,
      default: 14,
    },
    toursTotalDistance: {
      type: Number,
      default: 90,
    },
    toursDate: {
      type: Array,
      default: () => [],
    },
    toursPrice: {
      type: Number,
      default: 950,
    },
  },
  methods: {
    goToDescription(id) {
      this.$router.push({ name: "description", params: { tour_id: id } });
    },
  },
};
</script>

<style lang="css" scoped>
.card {
  height: 250px;
  width: 300px;
  margin: 25px;
}
img {
  height: 200px;
  width: 275px;
}
</style>
