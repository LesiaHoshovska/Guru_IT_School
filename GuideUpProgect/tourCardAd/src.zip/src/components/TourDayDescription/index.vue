<template>
  <div>
    <div>Day{{ dayNumber }}: {{ dayTittle }}</div>
    <div>{{ dayDescription }}</div>
    <div><img :src="dayPicsSrc" alt="" /></div>
  </div>
</template>

<script>
export default {
  name: "TourDayDescription",
  props: {
    tourTittle: {
      type: String,
      default: "No name",
    },
    dayNumber: {
      type: Number,
      default: null,
    },
    dayTittle: {
      type: String,
      default: null,
    },
    dayDescription: {
      type: String,
      default: null,
    },
    dayPicsSrc: {
      type: String,
      default: null,
    },
  },
};
</script>

<style lang="scss" scoped></style>
